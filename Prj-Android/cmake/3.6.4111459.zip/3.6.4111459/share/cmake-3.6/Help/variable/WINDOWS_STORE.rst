WINDOWS_STORE
-------------

True when the :variable:`CMAKE_SYSTEM_NAME` variable is set
to ``WindowsStore``.
