CMAKE_NO_SYSTEM_FROM_IMPORTED
-----------------------------

Default value for :prop_tgt:`NO_SYSTEM_FROM_IMPORTED` of targets.

This variable is used to initialize the :prop_tgt:`NO_SYSTEM_FROM_IMPORTED`
property on all the targets.  See that target property for additional
information.
