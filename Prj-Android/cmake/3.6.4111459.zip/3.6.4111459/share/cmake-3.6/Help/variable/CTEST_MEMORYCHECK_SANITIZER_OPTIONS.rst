CTEST_MEMORYCHECK_SANITIZER_OPTIONS
-----------------------------------

Specify the CTest ``MemoryCheckSanitizerOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
