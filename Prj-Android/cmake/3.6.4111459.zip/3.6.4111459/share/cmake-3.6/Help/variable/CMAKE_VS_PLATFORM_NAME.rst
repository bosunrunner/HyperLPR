CMAKE_VS_PLATFORM_NAME
----------------------

Visual Studio target platform name.

VS 8 and above allow project files to specify a target platform.
CMake provides the name of the chosen platform in this variable.
