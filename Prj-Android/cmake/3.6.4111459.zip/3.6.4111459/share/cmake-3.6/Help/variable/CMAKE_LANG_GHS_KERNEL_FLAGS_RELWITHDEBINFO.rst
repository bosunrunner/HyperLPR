CMAKE_<LANG>_GHS_KERNEL_FLAGS_RELWITHDEBINFO
--------------------------------------------

GHS kernel flags for ``RelWithDebInfo`` type or configuration.

``<LANG>`` flags used when :variable:`CMAKE_BUILD_TYPE` is ``RelWithDebInfo``
(short for Release With Debug Information).
