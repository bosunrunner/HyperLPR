CMAKE_<LANG>_FLAGS_RELWITHDEBINFO
---------------------------------

Flags for ``RelWithDebInfo`` type or configuration.

``<LANG>`` flags used when :variable:`CMAKE_BUILD_TYPE` is ``RelWithDebInfo``
(short for Release With Debug Information).
