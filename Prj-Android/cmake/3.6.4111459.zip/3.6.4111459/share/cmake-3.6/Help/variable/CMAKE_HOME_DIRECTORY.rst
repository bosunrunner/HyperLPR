CMAKE_HOME_DIRECTORY
--------------------

Path to top of source tree.

This is the path to the top level of the source tree.
