CMAKE_ANDROID_ASSETS_DIRECTORIES
--------------------------------

Default value for the :prop_tgt:`ANDROID_ASSETS_DIRECTORIES` target property.
See that target property for additional information.
