MSVC14
------

``True`` when using Microsoft Visual C++ 14.0.

Set to ``true`` when the compiler is version 14.0 of Microsoft Visual C++.
