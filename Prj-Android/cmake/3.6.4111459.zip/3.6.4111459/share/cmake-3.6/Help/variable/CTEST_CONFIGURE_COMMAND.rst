CTEST_CONFIGURE_COMMAND
-----------------------

Specify the CTest ``ConfigureCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
