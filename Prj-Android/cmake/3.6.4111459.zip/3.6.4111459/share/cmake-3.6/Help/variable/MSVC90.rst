MSVC90
------

``True`` when using Microsoft Visual C++ 9.0.

Set to ``true`` when the compiler is version 9.0 of Microsoft Visual C++.
