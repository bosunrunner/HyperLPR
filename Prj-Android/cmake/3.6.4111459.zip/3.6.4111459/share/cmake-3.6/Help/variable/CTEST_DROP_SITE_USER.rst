CTEST_DROP_SITE_USER
--------------------

Specify the CTest ``DropSiteUser`` setting
in a :manual:`ctest(1)` dashboard client script.
